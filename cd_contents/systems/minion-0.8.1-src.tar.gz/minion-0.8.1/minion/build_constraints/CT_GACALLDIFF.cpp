#include "../minion.h"
/* Minion Constraint Solver
   http://minion.sourceforge.net
   
   For Licence Information see file LICENSE.txt 
*/

#include "../constraints/constraint_gacalldiff.h"

BUILD_CT(CT_GACALLDIFF, 1)
