#include "../minion.h"
/* Minion Constraint Solver
   http://minion.sourceforge.net
   
   For Licence Information see file LICENSE.txt 
*/

#include "../constraints/reify_true.h"

BUILD_CT(CT_REIFYIMPLY_NEW, 1)
