#include "../minion.h"
/* Minion Constraint Solver
   http://minion.sourceforge.net
   
   For Licence Information see file LICENSE.txt 
*/

#include "../constraints/reify_true.h"
#include "../constraints/reify_true_old.h"

BUILD_CT(CT_REIFYIMPLY, 1)
