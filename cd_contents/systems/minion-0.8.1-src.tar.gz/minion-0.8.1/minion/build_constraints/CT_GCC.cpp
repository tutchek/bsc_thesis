#include "../minion.h"
/* Minion Constraint Solver
   http://minion.sourceforge.net
   
   For Licence Information see file LICENSE.txt 
*/

#include "../constraints/constraint_gccweak.h"
#include "../constraints/constraint_gcc.h"

BUILD_CT(CT_GCC, 2)
