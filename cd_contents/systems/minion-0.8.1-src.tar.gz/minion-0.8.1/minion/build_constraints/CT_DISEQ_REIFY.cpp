#include "../minion.h"
/* Minion Constraint Solver
   http://minion.sourceforge.net
   
   For Licence Information see file LICENSE.txt 
*/

#include "../constraints/reify.h"
#include "../constraints/constraint_equal.h"

BUILD_CT(CT_DISEQ_REIFY, 3)
