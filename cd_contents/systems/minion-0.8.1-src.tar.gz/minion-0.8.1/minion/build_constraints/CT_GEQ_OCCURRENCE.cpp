#include "../minion.h"
/* Minion Constraint Solver
   http://minion.sourceforge.net
   
   For Licence Information see file LICENSE.txt 
*/

#include "../constraints/constraint_occurrence.h"

BUILD_CT(CT_GEQ_OCCURRENCE, 1)
