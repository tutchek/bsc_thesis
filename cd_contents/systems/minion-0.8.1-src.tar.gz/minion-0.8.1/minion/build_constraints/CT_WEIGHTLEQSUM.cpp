#include "../minion.h"
/* Minion Constraint Solver
   http://minion.sourceforge.net
   
   For Licence Information see file LICENSE.txt 
*/

#include "../constraints/sum_constraints/constraint_weightedsum.h"

BUILD_CT(CT_WEIGHTLEQSUM, 2)
