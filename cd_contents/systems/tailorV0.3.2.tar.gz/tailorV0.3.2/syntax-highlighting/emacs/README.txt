===============================================
SYNTAX HIGHLIGHTING IN EMACS
===============================================
support: andrea@cs.st-and.ac.uk

Peter Gregory (peter.gregory@cis.strath.ac.uk)
provided an Emacs mode that produces syntax
highlighting for Essence' files that end with 
suffix .eprime in editor Emacs. 

The Emacs Mode for Minion is based on the 
Essence' mode, but can be used separately.


Files
-----
eprime-mode.el		Emacs mode for Essence'
minion-mode.el          Emacs mode for Minion format

Installation
------------

You need to edit Emacs' config file in your 
home-directory at: ~/.emacs. If the files does 
not exist, create it. Copy the following lines 
into that file and change the path to wherever 
you put the file eprime-mode.el:

(setq auto-mode-alist (cons '("\\.eprime" . eprime-mode) auto-mode-alist))
(autoload 'eprime-mode "/path/to/where/you/put/eprime-mode" "Major mode for Essence'" t)


and for minion.el:

(setq auto-mode-alist (cons '("\\.minion" . minion-mode) auto-mode-alist))
(autoload 'minion-mode "/path/to/where/you/put/minion-mode" "Major mode for Minion" t)
