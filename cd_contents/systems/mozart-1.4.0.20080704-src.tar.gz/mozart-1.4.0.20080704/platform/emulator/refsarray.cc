/*
 *  Authors:
 *    Christian Schulte <schulte@ps.uni-sb.de>
 * 
 *  Contributors:
 *    Ralf Scheidhauer (Ralf.Scheidhauer@ps.uni-sb.de)
 *    Michael Mehl (mehl@dfki.de)
 * 
 *  Copyright:
 *    Michael Mehl, 1995-1999
 *    Ralf Scheidhauer, 1995-1999
 *    Christian Schulte, 2000
 * 
 *  Last change:
 *    $Date: 2000-10-24 15:54:05 +0200 (Tue, 24 Oct 2000) $ by $Author: schulte $
 *    $Revision: 13301 $
 * 
 *  This file is part of Mozart, an implementation 
 *  of Oz 3:
 *     http://www.mozart-oz.org
 * 
 *  See the file "LICENSE" or
 *     http://www.mozart-oz.org/LICENSE.html
 *  for information on usage and redistribution 
 *  of this file, and for a DISCLAIMER OF ALL 
 *  WARRANTIES.
 *
 */

#if defined(INTERFACE)
#pragma implementation "refsarray.hh"
#endif

#include "refsarray.hh"

