#include "lpkit.h"


void presolve(lprec *lp)
{
  fprintf(stderr, "Entering presolve\n");


}

