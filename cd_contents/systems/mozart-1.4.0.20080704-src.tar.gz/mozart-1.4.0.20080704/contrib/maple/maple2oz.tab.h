#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	TID	257
#define	NUMBER	258
#define	ABS	259


extern YYSTYPE yylval;
